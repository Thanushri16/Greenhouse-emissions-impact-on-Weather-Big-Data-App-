namespace java edu.uchicago.mpcs53013.weatherSummary

struct WeatherSummary {
    1: required string countryCode;
    2: required string station;
    3: required i16 year;
    4: required byte month;
    5: required byte day;
    6: required string valueType;
    7: required double meanTemperature;
}





