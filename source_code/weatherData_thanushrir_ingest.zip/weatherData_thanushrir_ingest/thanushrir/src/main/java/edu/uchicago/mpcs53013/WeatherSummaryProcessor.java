package edu.uchicago.mpcs53013;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import java.util.zip.ZipException;


import edu.uchicago.mpcs53013.weatherSummary.WeatherSummary;
// import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
// import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;



public abstract class WeatherSummaryProcessor {
	static class MissingDataException extends Exception {

	    public MissingDataException(String message) {
	        super(message);
	    }

	    public MissingDataException(String message, Throwable throwable) {
	        super(message, throwable);
	    }

	}
	
	static double tryToReadMeasurement(String name, String s, String missing) throws MissingDataException {
		if(s.equals(missing))
			throw new MissingDataException(name + ": " + s);
		s = s.replaceAll("[^0-9]","");
		return Double.parseDouble(s.trim());
	}

	void processLine(String line, String archiveEntryName) throws IOException {
		try {
			processWeatherSummary(weatherFromLine(line), archiveEntryName);
		} catch(MissingDataException e) {
			// Just ignore lines with missing data
		}
	}

	abstract void processWeatherSummary(WeatherSummary summary, String fileName) throws IOException;
	BufferedReader getFileReader(InputStream is) throws FileNotFoundException, IOException {
		try
		{
			return new BufferedReader(new InputStreamReader(new GZIPInputStream(is)));
		}
		catch(ZipException z)
		{
			// Just ignore the files that are not in gzip format
			System.out.println("Log message: Filename not in GZip format");
			return null;
		}
	}
	
	void processNoaaFile(InputStream is, String archiveEntryName) throws IOException {
		BufferedReader br = getFileReader(is);
		// br.readLine(); // Discard header
		String line;
		while((line = br.readLine()) != null) {
			processLine(line, archiveEntryName);
		}
	}


//	void processNoaaTarFile(InputStream is) throws IOException {
//		TarArchiveInputStream tarArchiveInputStream = new TarArchiveInputStream(is);
//		TarArchiveEntry entry;
//		while ((entry = (TarArchiveEntry)tarArchiveInputStream.getNextEntry()) != null) {
//			if(!entry.getName().endsWith(".gz"))
//				continue;
//			processNoaaFile(tarArchiveInputStream, entry.getName());
//		}
//	}
	
	WeatherSummary weatherFromLine(String line) throws NumberFormatException, MissingDataException {
		WeatherSummary summary 
			= new WeatherSummary(line.substring(0, 2).trim(),
				                      line.substring(0, 11).trim(),
				                      Short.parseShort(line.substring(12, 16).trim()),
				                      Byte.parseByte(line.substring(16, 18).trim()),
				                      Byte.parseByte(line.substring(18, 20).trim()),
				                      line.substring(21, 25).trim(),
				                      tryToReadMeasurement("Mean Temperature", line.substring(26, 29), "999.9")
				                      );
		return summary;
	}

}
