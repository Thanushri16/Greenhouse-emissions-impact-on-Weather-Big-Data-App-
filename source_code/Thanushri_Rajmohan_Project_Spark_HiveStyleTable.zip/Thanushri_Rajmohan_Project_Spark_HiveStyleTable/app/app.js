'use strict';

const http = require('http');
var assert = require('assert');
const express= require('express');
const app = express();
const mustache = require('mustache');
const filesystem = require('fs');
const url = require('url');
const port = Number(process.argv[2]);

const hbase = require('hbase')
var hclient = hbase({ host: process.argv[3], port: Number(process.argv[4])})

hclient.table('thanushrir_project_spark_hivestyle').scan(
	{
		filter: {
			type: "PrefixFilter",
			value: "UK"
		},
		maxVersions: 1
	},
	function (err, cells) {
		console.info(cells);
		console.info(groupByYear("UK", cells));
	})

function removePrefix(text, prefix) {
	if(text.indexOf(prefix) != 0) {
		throw "missing prefix"
	}
	return text.substr(prefix.length)
}


function rowToMap(row) {
	var stats = {}
	row.forEach(function (item) {
		stats[item['column']] = Number(item['$'])
	});
	return stats;
}


function groupByYear(countrycode, cells) {
	function yearValuesToRows(year, yearValues) {
		let yearRow = { 'year' : year };
		yearRow['country'] = yearValues['country'];
		yearRow['emissions'] = yearValues['emissions'];
		yearRow['avg_temp'] = yearValues['avg_temp'];
		console.info(yearRow)
		return yearRow;
	}
	let result = [];
	let yearValues;
	let lastYear = 0;
	cells?.forEach(function (cell) {
		let year = Number(removePrefix(cell['key'], countrycode));
		if(lastYear !== year) {
			if(yearValues) {
				result.push(yearValuesToRows(lastYear, yearValues))  //change lastYear to year
			}
			yearValues = {}
		}
		yearValues[removePrefix(cell['column'], 'values:')] = cell['$']
		lastYear = year;
	})
	result.push(yearValuesToRows(lastYear, yearValues))
	return result;
}



app.use(express.static('public'));
app.get('/emissions_weather.html',function (req, res) {
    const countrycode=req.query['countrycode'];
	hclient.table('thanushrir_project_spark_hivestyle').scan(
		{
			filter: {
				type: "PrefixFilter",
				value: countrycode
			},
			maxVersions: 1
		},
		function (err, cells) {
			let template = filesystem.readFileSync("result.mustache").toString();
			let input = { values: groupByYear(countrycode, cells)};
			let dict_values = { countrycode : req.query['countrycode'],
				values: groupByYear(countrycode, cells)}
			let html = mustache.render(template, dict_values);

			console.info("CALCULATING VALUES")
			const years = Object.values(dict_values.values).map(v => v.year);
			const emissions = Object.values(dict_values.values).map(v => v.emissions);
			const avg_temp = Object.values(dict_values.values).map(v => v.avg_temp);


		res.send(html);

			var plotly = require('plotly')('thanushrir', 'lTLcdRpltJY7IbYOT0PM');

			var emissions_data = [
				{
					x: years,
					y: emissions,
					name: 'emissions data',
					type: "scatter"
				}
			];
			var temperature_data = [
				{
					x: years,
					y: avg_temp,
					name: 'temperature data',
					yaxis: 'y2',
					type: "scatter"
				}
			];
			var data = [emissions_data[0], temperature_data[0]];
			var layout = {
				title: 'Emissions-TemperatureChange-'+countrycode,
				yaxis: {title: 'Emissions (in tonnes)'},
				yaxis2: {
					title: 'Average Temperature (in °F)',
					titlefont: {color: 'rgb(148, 103, 189)'},
					tickfont: {color: 'rgb(148, 103, 189)'},
					overlaying: 'y',
					side: 'right'
				}
			};
			var graphOptions = {filename: "Emissions-TemperatureChange-"+countrycode, fileopt: "overwrite", layout: layout}; // , world_readable: true
			plotly.plot(data, graphOptions, function (err, msg) {
				console.log(msg);
			});

		})
});

app.listen(port);
